import { Box, Stack } from '@mui/material';
import Dashboard from 'renderer/components/Dashboard';
import PageTopbar from 'renderer/components/PageTopbar';
import { useLocation, useNavigate, Outlet } from 'react-router-dom';
import styles from './styles.module.css';
import AddScriptsBtns from './Scripts/components/AddScriptsBtns';

const links = [
  { text: 'Smart Tags', link: 'smart-tags' },
  { text: 'Auto Follow', link: 'auto-follow' },
  { text: 'Profile Promotion', link: 'profile-promotion' },
  { text: 'Trial Links', link: 'trial-links' },
  { text: 'Tracking Links', link: 'tracking-links' },
  { text: 'Scripts', link: 'scripts' },
];

export default function Growth() {
  const location = useLocation();
  const path = location.pathname;
  const navigate = useNavigate();

  const isScriptsPage = path.includes('scripts');

  return (
    <Dashboard>
      <section className={styles.wrapper}>
        <PageTopbar>
          <Stack
            alignItems="center"
            direction="row"
            marginBottom="20px"
            width="100%"
            justifyContent="space-between"
          >
            <PageTopbar.HeaderText>Growth</PageTopbar.HeaderText>
            {isScriptsPage && <AddScriptsBtns />}
          </Stack>
          <Stack flexDirection="row" sx={{ position: 'absolute', bottom: 0 }}>
            {links.map(({ link, text }) => (
              <PageTopbar.Button
                key={text}
                color="secondary"
                text={text}
                isActiveLink={path.includes(link)}
                isLink
                onClick={() => navigate(`/growth/${link}`)}
              />
            ))}
          </Stack>
        </PageTopbar>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: 'minmax(min-content, 380px) 1fr',
            height: '100%',
          }}
        >
          <Outlet />
        </Box>
      </section>
    </Dashboard>
  );
}
